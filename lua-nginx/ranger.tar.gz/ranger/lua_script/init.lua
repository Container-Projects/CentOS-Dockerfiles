local config = require "rangerConfig"

local status = require "status"
status.init()
