local status = require "status"
local summary = require "summary"

status.log()
summary.log()
